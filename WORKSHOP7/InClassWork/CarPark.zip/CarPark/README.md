Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
npm install --global yarn

//npx create-react-app tutorialreact

yarn create vite CarPark --template react


Homework 2

Add new car
Style modal window
Car details modal, styled, show
Save new car to localstorage (optional) / API (optional)Add new car