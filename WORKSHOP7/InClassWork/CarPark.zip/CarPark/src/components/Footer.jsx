
const Footer = () => {
  return (
    <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "2em"
    }}>
        This site is for learning
    </div>
  )
}

export default Footer