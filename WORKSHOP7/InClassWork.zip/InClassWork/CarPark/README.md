Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
npm install --global yarn

//npx create-react-app tutorialreact

yarn create vite CarPark --template react



Content.jsx
Footer.jsx
Header.jsx
Modal.jsx