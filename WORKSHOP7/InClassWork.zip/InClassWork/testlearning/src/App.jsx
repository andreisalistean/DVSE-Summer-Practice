import './App.css'
import { CarList } from './CarList'

export function App() {
  return <div>
    <h1>Test</h1>
    <CarList manufacturerLabel="Manufacturer"/>
    
  </div>
}

