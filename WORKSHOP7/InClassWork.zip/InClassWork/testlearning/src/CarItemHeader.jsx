/* eslint-disable react/prop-types */
const CarItemHeader = ({children}) => {
    return <>
        {children}
    </>
}

export default CarItemHeader