import { COLORS, FONTS, STYLES } from "./theme";

export { COLORS, FONTS, STYLES };
